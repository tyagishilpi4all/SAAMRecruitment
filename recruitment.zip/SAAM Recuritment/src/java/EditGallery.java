/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import connect.connect_db;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

/**
 *
 * @author shilpi
 */
@MultipartConfig
(
        fileSizeThreshold = 1024*1024*2,
        maxFileSize = 1024*1024*10,
        maxRequestSize = 1024*1024*50
)
public class EditGallery extends HttpServlet {

     private final String filePath="C:\\Users\\shilpi\\Documents\\NetBeansProjects\\SAAM Recuritment\\web\\admin\\images";
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
             String Id = request.getParameter("id");
            String Title = request.getParameter("title");
            Part filePart = request.getPart("image");
            String Status= request.getParameter("status");
            String PortfolioName = request.getParameter("portfolio");
            System.out.println(Id+" "+Title+" "+Status);
            String photo;
            String fileName;
            if(Title.contains(".jpg")){
                fileName=Title;
            }
            else{
                fileName=Title+".jpg";
            }
            try{
                if(filePart.getSize()>0){
                     photo=filePath+File.separator+fileName;
                filePart.write(photo);
                Connection con = new connect_db().getConnection();
                PreparedStatement ps = con.prepareStatement("update Gallery set image=? where id=?");
                ps.setString(1, fileName);
                ps.setString(2, Id);
                int i = ps.executeUpdate();
                if(i>0){
                    out.println("<script type=\"text/javascript\">");
                    out.println("alert('Successfully Gallary Edit')");
                    out.println("window.location.href='admin/view_Gallery.jsp'");
                    out.println("</script>");
                }
                else{
                    out.println("<script type=\"text/javascript\">");
                    out.println("alert('You are not succeed in editing Gallery')");
                    out.println("window.location.href='admin/edit_Gallery.jsp'");
                    out.println("</script>");
                }
                }
                else{
                     Connection conn = new connect_db().getConnection();
                PreparedStatement ps1 = conn.prepareStatement("update Gallery set status=?,portfolioName=? where id=?");
                ps1.setString(1, Status);
                ps1.setString(2, PortfolioName);
                ps1.setString(3, Id);
                int i = ps1.executeUpdate();
                if(i>0){
                    out.println("<script type=\"text/javascript\">");
                    out.println("alert('Successfully Edit Gallery status')");
                    out.println("window.location.href='admin/view_Gallery.jsp'");
                    out.println("</script>");
                }
                else{
                    out.println("<script type=\"text/javascript\">");
                    out.println("alert('Gallery status not edit')");
                    out.println("window.location.href='admin/edit_Gallery.jsp'");
                    out.println("</script>");
                }
                }
          
                
            }
            catch(Exception e){
                System.out.println(e);
            }
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
