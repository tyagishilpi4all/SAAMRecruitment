import connect.connect_db;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;
@MultipartConfig(fileSizeThreshold=1024*1024*2, // 2MB
                 maxFileSize=1024*1024*10,      // 10MB
                 maxRequestSize=1024*1024*50)

public class signUpFront extends HttpServlet {
        private static final String SAVE_DIR="C:\\Users\\shilpi\\Documents\\NetBeansProjects\\SAAM Recuritment\\web\\img";
    
    protected void service(HttpServletRequest request, HttpServletResponse response)
            throws ServletException,IOException{
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        String savePath = "C:" + File.separator + SAVE_DIR;
        File fileSaveDir=new File(savePath);
        if(!fileSaveDir.exists()){
            fileSaveDir.mkdir();
           }            
            //int id=Integer.parseInt(request.getParameter("id"));
            String type=request.getParameter("title"); 
            Part part=request.getPart("image");
            String fileName=extractFileName(part);
            fileName=new File(fileName).getName();
             
            /*if you may have more than one files with same name then you can calculate some random characters and append that characters in fileName so that it will  make your each image name identical.*/
            part.write(savePath + File.separator + fileName);
           /* 
            //You need this loop if you submitted more than one file
            for (Part part : request.getParts()) {
            String fileName = extractFileName(part);
            part.write(savePath + File.separator + fileName);
        }*/
           String Name = request.getParameter("name");
           String Email = request.getParameter("email");
           String Password = request.getParameter("pass");
           Part filePart = request.getPart("img");
           String Occupation = request.getParameter("occupation");
           String Phone = request.getParameter("phone");
           String Address = request.getParameter("address");
           String subject = "User SignUp";
           int flag=1;
           System.out.println(Name+" "+Email+" "+Password+" "+Occupation+" "+Phone+" "+Address);
            try
    		{
                   Connection con= new connect_db().getConnection();
                PreparedStatement ps= con.prepareStatement("select * from signupfront where email=?");
                ps.setString(1, Email);
                ResultSet rs = ps.executeQuery();
                if(rs.next()){
                    if(rs.getString("email").equals(Email)){
                        flag=0;
                        out.println("<script type=\"text/javascript\">");
                         out.println("alert('Already exist')");
                         out.println("window.location.href='login.jsp'");
                         out.println("</script>");
                    }
                }
                else if(flag==1){
                    Connection conn = new connect_db().getConnection();
                    PreparedStatement ps1 = conn.prepareStatement("insert into signupfront(name,email,password,image,occupation,phone,address) values(?,?,?,?,?,?,?)");
                    ps1.setString(1, Name);
                    ps1.setString(2, Email);
                    ps1.setString(3, Password);
                    ps1.setString(4, fileName);
                    ps1.setString(5, Occupation);
                    ps1.setString(6, Phone);
                    ps1.setString(7, Address);
                    int i =ps1.executeUpdate();
                    if(i>0){
                        String MessageBody ="Thank You"+" "+Name+" "+"you are successfully Registered";
                    mail.Mailerr.send(Email, subject, MessageBody);
                        out.println("<script type=\"text/javascript\">");
                         out.println("alert('Successfully SignUp')");
                         out.println("window.location.href='login.jsp'");
                         out.println("</script>");
                    }
                    else{
                        out.println("<script type=\"text/javascript\">");
                         out.println("alert('You are not signUp')");
                         out.println("window.location.href='signup.jsp'");
                         out.println("</script>");
                    }
                }
                }
            catch(Exception e)
            {
                System.out.println(e);
            }
    }
    // file name of the upload file is included in content-disposition header like this:
    //form-data; name="dataFile"; filename="PHOTO.JPG"
    private String extractFileName(Part part) {
        String contentDisp = part.getHeader("content-disposition");
        String[] items = contentDisp.split(";");
        for (String s : items) {
            if (s.trim().startsWith("filename")) {
                return s.substring(s.indexOf("=") + 2, s.length()-1);
            }
        }
        return "";
    }
}

